/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";
import fetchAddress from "../api/fetchAddress";
import transcationList from "../api/transaction";
import listWallet from "../api/walletList";

interface Wallet {
  name: string;
  transactions: any;
}

const TxnTable = () => {
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const fetchTransactions = async (address: string): Promise<string | any[]> => {
    try {
      const transactions = await transcationList(address);
      return transactions;
    } catch (error) {
      console.error(`Error fetching transactions for address ${address}:`, error);
      return [];
    }
  };

  const fetchWallets = async (): Promise<Wallet[]> => {
    try {
      const walletListString = await listWallet();

      const walletList: string[] = JSON.parse(walletListString);
      const walletsWithTransactions = await Promise.all(walletList.map(async (walletName) => {
        let address = await fetchAddress(walletName);
        address = address.replace(/"/g, '');
        const transactions = await fetchTransactions(address);
        return {
          name: walletName,
          transactions: transactions,
        };
      }));

      return walletsWithTransactions;
    } catch (error) {
      console.error("Error fetching wallet data:", error);
      return [];
    }
  };

  useEffect(() => {
    setIsLoading(true);
    fetchWallets()
      .then((wallets) => setWallets(wallets))
      .catch((error) => console.error("Error fetching wallets:", error))
      .finally(() => setIsLoading(false));

      console.log("use", wallets);
  }, []);

  const handleSync = async () =>{
    setIsLoading(true);
    fetchWallets()
      .then((wallets) => setWallets(wallets))
      .catch((error) => console.error("Error fetching wallets:", error))
      .finally(() => setIsLoading(false));
  }

  return (
    <div className="txn-table-container">
      <button className="sync-btn" onClick={handleSync} disabled={isLoading}>
        {isLoading ? "Syncing..." : "Sync"}
      </button>
      <h2>  All Transaction</h2>
      <table className="txn-table">
        <thead>
          <tr>
            <th>Coin</th>
            <th>Wallet</th>
            <th>Amount</th>
            <th>Result</th>
            <th>Status</th>
          </tr>
        </thead>
        {wallets ? wallets.map((wallet) => (
  <tbody key={wallet.name}>
    
        {wallet.transactions ? wallet.transactions.map((transaction, index) => (
          <tr key={index}>
            <td>{new Date(transaction.timestamp).toLocaleString()}</td>
            <td>{wallet.name}</td>
            <td>{(transaction.value)/ Math.pow(10, 8)}</td>
            <td>{(transaction.spent) ? "SENT" : "RECEIVED"}</td>
            <td>{(transaction.type === "confirmed") ? "SUCCESS" : "Unconfirmed"}</td>
          </tr>
        )) : <li>No transactions found</li>}
  </tbody>
)) : <tr><td>No transactions found</td></tr>}

        
      </table>
    </div>
  );
};

export default TxnTable;
