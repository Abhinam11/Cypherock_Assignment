import React, { useState } from 'react';
import WalletTable from '../components/WalletTable';
import Modal from '../components/Modal';
import importWallet from '../api/importWallet';

const Wallets = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [walletName, setWalletName] = useState('');
  const [mnemonic, setMnemonic] = useState('');

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleSubmit = async() => {
    
    const res = await importWallet(walletName, mnemonic);
    console.log("import res ", res);
    setWalletName('');
    setMnemonic('');
    handleCloseModal();
  };

  return (
    <div className='screen'>
      <WalletTable />
      <div className='import'>
      <button onClick={handleOpenModal}>Import Wallet</button>
      </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal}>
        <h2>Import Wallet</h2>
        <div>
          <label>Wallet Name:</label>
          <input
            type="text"
            value={walletName}
            onChange={(e) => setWalletName(e.target.value)}
          />
        </div>
        <div>
          <label>Wallet Mnemonic</label>
          <textarea
            className='mnemonic-input'
            rows={5}
            cols={1}
            value={mnemonic}
            onChange={(e) => setMnemonic(e.target.value)}
          />
        </div>
        <button onClick={handleSubmit}>Import</button>
      </Modal>
    </div>
  );
};

export default Wallets;
