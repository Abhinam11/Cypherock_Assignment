/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";

const fetchAddress = async (name: string): Promise<string> => {
  try {
    const res = await axios.get(
      `https://api.blockcypher.com/v1/btc/test3/wallets/${name}?token=${import.meta.env.VITE_TOKEN}`
    );
    console.log("fetchaddress", res);
    return JSON.stringify(res.data.addresses[0]);
  } catch (error: any) {
    if (error?.response?.status === 409) {
      return error.response.data.error;
    }
    return error.toString();
  }
};

export default fetchAddress;
