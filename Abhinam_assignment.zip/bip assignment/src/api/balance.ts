/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";

const balanceWallet = async (addrs: string): Promise<string> => {
  try {
    console.log("addrs", `https://api.blockcypher.com/v1/btc/test3/addrs/${addrs}/balance`);
    const res = await axios.get(
      `https://api.blockcypher.com/v1/btc/test3/addrs/${addrs}/balance`
    );
    
    return ((res.data.final_balance)/Math.pow(10, 8)).toString();
  } catch (error: any) {
    console.log(error);
    if (error?.response?.status === 409) {
      return error.response.data.error;
    }
    return error.toString();
  }
};

export default balanceWallet;
