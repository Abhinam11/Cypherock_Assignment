import { useEffect, useState } from "react";
import fetchAddress from "../api/fetchAddress";
import listWallet from "../api/walletList";
import balanceWallet from "../api/balance";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";

interface Wallet {
  name: string;
  balance: string;
}

const WalletTable = () => {
  const [wallets, setWallets] = useState<Wallet[]>([]);

  const getBalanceForWallet = async (walletName: string): Promise<string> => {
    try {
      let addr = await fetchAddress(walletName)
      console.log(addr)
      addr = addr.replace(/"/g, '');
      const res = await balanceWallet(addr);
      console.log("final", addr, res);
      return res; 

    } catch (error) {
      console.error(`Error fetching balance for ${walletName}:`, error);
      return "0.00";
    }
  };

  const fetchWallets = async (): Promise<Wallet[]> => {
    try {
      const walletListString = await listWallet();
      console.log("check", walletListString);
      const walletList: string[] = JSON.parse(walletListString);
      const walletAddressesMap: Wallet[] = await Promise.all(walletList.map(async (walletName) => ({
        name: walletName,
        balance: await getBalanceForWallet(walletName),
      })));
      return walletAddressesMap;
    } catch (error) {
      console.error("Error fetching wallet list:", error);
      return [];
    }
  };

  const walletsFetch = async () =>{
    const allWallets = await fetchWallets();
    setWallets(allWallets);
  }
  useEffect(()=>{
    walletsFetch();
  }, [])

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const handleSync = async () =>{
    setIsLoading(true);
    await walletsFetch();
    setIsLoading(false);
  }
  return (
    <div className="graph-container">
      <div className="sync-btn">
      <button onClick={handleSync}>{isLoading ? 'Syncing...' : 'Sync'}</button>
      </div>
      <h2>List of wallets</h2>
      <table className="table">
          <thead>
            <tr>
              <th>Coin</th>
              <th>Holding</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {wallets.map((wallet) => (
              <tr key={wallet.name}>
                <td>{wallet.name}</td>
                <td>{wallet.balance}</td>
                <td><FontAwesomeIcon icon={faTrash}/></td>
              </tr>
            ))}
          </tbody>
        </table>
    </div>
  );
};

export default WalletTable;
