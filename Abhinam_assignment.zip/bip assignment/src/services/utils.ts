import * as fs from "fs";
import * as path from "path";
const addToFile = (name: string, addr: string) => {
  try {
    const filePath = path.join(__dirname, "data.json");
    let data = [];

    if (fs.existsSync(filePath)) {
      const rawData = fs.readFileSync(filePath);
      data = JSON.parse(rawData.toString());
    }

    data.push({ name, addr });

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (error) {}
};

const getFileData = (): { name: string; addr: string }[] => {
  const filePath = path.join(__dirname, "data.json");

  try {
    if (fs.existsSync(filePath)) {
      const rawData = fs.readFileSync(filePath);
      return JSON.parse(rawData.toString());
    } else {
      return [];
    }
  } catch (error) {
    return [];
  }
};
export { addToFile, getFileData };
