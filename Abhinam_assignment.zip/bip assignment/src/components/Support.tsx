import './support.css'; 

const SupportBtn = () => {

  return (
    <div className="supportbtn">
        <button onClick={()=>{}}>Support</button>
    </div>
  );
};

export default SupportBtn;
