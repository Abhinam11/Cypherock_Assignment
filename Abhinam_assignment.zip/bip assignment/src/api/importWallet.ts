/* eslint-disable @typescript-eslint/no-explicit-any */
import { mnemonicToSeedSync } from "bip39";
// import * as bitcoinjs from "bitcoinjs-lib";

// import bip32 from "bip32";
import BIP32Factory from 'bip32';
import * as ecc from "tiny-secp256k1";
import axios from "axios";
import { Buffer } from 'buffer';


window.Buffer = Buffer;

const bip32 = BIP32Factory(ecc);
const importWallet = async (
  name: string,
  mnemonic: string
): Promise<string> => {
  try {

    const res = await axios.post(
      `https://api.blockcypher.com/v1/btc/test3/wallets?token=${import.meta.env.VITE_TOKEN}`,
      JSON.stringify({
        name: name,
        addresses: [createWalletAddress(mnemonic)],
      })
    );

    return JSON.stringify({ name: name, addresse: res.data.addresses[0] });
  } catch (error: any) {
    if (error?.response?.status === 409) {
      return error.response.data.error;
    }
    return error.toString();
  }
};

const createWalletAddress = (mnemonic: string) => {
  const seed = mnemonicToSeedSync(mnemonic);

  const network = window.bitcoin.networks.testnet;
  console.log("net", network);
  const node = bip32.fromSeed(seed, network);
  return window.bitcoin.payments.p2pkh({ pubkey: node.publicKey, network: network }).address;
};
export default importWallet;
