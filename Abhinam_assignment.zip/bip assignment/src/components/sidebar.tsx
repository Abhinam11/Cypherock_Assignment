import { useState } from 'react';
import './styles.css'; 
import SupportBtn from './Support';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeItem, setActiveItem] = useState('Wallets');

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleItemClick = (itemName) => {
    setActiveItem(itemName);
    
  };

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-toggle" onClick={toggleSidebar}>
        <div className="bar"></div>
        <div className="bar"></div>
        <div className="bar"></div>
      </div>
      <ul className="nav">
      <Link to="/">
        <li className={`nav-item ${activeItem === 'Wallets' ? 'active' : ''}`} onClick={() => handleItemClick('Wallets')}>
        Wallets
        </li>
        </Link>
        <Link to="/transactions">
        <li className={`nav-item ${activeItem === 'Transactions' ? 'active' : ''}`} onClick={() => handleItemClick('Transactions')}>
        Transactions
        </li>
        </Link>
      </ul>
      <SupportBtn />
    </div>
  );
};

export default Sidebar;
