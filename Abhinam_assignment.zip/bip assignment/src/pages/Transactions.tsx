import React from 'react';
import TxnTable from '../components/TxnTable';

const Transactions = () => {
  return (
    <div>
      <TxnTable />
    </div>
  );
}

export default Transactions;
