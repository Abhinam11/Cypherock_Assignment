/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";

const transcationList = async (addrs: string): Promise<any[] | string> => {
 
  try {
    const response = await axios.get(
      `https://api.blockcypher.com/v1/btc/test3/addrs/${addrs}`
    );

    let allTransactions: any[] = [];

    if (response.data.txrefs) {
      const confirmedTransactions = response.data.txrefs.map((tx: any) => ({
        timestamp: tx.confirmed,
        value: tx.value,
        spent: tx.spent,
        confirmations: tx.confirmations,
        type: "confirmed",
      }));

      allTransactions = allTransactions.concat(confirmedTransactions);
    }

    if (response.data.unconfirmed_txrefs) {
      
      const unconfirmedTransactions = response.data.unconfirmed_txrefs.map((tx:any) => ({
        timestamp: tx.received,
        value: tx.value,
        spent: tx.spent,
        confirmations: tx.confirmations || 0,
        type: "unconfirmed",
      }));

      allTransactions = allTransactions.concat(unconfirmedTransactions);
    }

    return allTransactions;
  } catch (error) {
    console.error("Error fetching transactions:", error);
    return [];
  }
};
export default transcationList;
