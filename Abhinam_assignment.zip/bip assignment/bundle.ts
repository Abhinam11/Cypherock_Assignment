import * as bitcoin from 'bitcoinjs-lib';
(window as any).bitcoin = bitcoin;
