import './App.css'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/sidebar';
import '@fortawesome/fontawesome-svg-core/styles.css';
import Wallets from './pages/Wallets';
import Transactions from './pages/Transactions';

function App() {


  return (
    <Router>
      <div className='home'>
      <Sidebar />
    </div>
      <Routes>
        <Route path="/" element={<Wallets />} />
        <Route path="/transactions" element={<Transactions />} />
      </Routes>
    </Router>
  )
}

export default App
