/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";

const listWallet = async (): Promise<string> => {
  try {

    const res = await axios.get(
      `https://api.blockcypher.com/v1/btc/test3/wallets?token=${import.meta.env.VITE_TOKEN}`
    );
    return JSON.stringify(res.data["wallet_names"]);
  } catch (error: any) {
    if (error?.response?.status === 409) {
      return error.response.data.error;
    }
    return error.toString();
  }
};

export default listWallet;
